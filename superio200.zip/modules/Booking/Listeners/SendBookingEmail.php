<?php
namespace Modules\Booking\Listeners;
class SendBookingEmail
{
}