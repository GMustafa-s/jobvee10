<?php
/**
 * Created by PhpStorm.
 * User: h2 gaming
 * Date: 7/3/2019
 * Time: 9:32 PM
 */
return [
    'candidate_route_prefix' => env("CANDIDATE_ROUTER_PREFIX","candidate"),
    'candidate_category_route_prefix' => env("CANDIDATE_CATEGORY_ROUTER_PREFIX","category")
];
