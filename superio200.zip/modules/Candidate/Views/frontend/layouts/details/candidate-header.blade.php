<div class="upper-box">
    <div class="auto-container">
        <!-- Candidate block Five -->
        <div class="candidate-block-five">
            <div class="inner-box">
                @include('Candidate::frontend.layouts.details.candidate-block')
                @include('Candidate::frontend.layouts.details.candidate-btn-box')
            </div>
        </div>
    </div>
</div>
