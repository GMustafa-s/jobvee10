<?php

return [
    'companies_route_prefix' => env("COMPANIES_ROUTER_PREFIX","companies"),
    'companies_category_route_prefix'=> env("COMPANIES_CATEGORY_ROUTER_PREFIX",'category'),
];
