<div class="form-group col-lg-4 col-md-12 col-sm-12">
    <span class="icon flaticon-search-1"></span>
    <input type="text" name="s" value="{{ Request::query("s") }}" placeholder="{{__("Job title, keywords, or company")}}">
</div>
