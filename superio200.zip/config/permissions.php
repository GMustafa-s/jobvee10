<?php

return [
    //GIG
    "gig_manage",
    "gig_manage_others",

    //candidate_manage
    "candidate_manage",
    "candidate_manage_others",

    //employer_manage
    "employer_manage",
    "employer_manage_others",

    //job_manage
    "job_manage",
    "job_manage_others",

    "skill_manage_others",
    "category_manage_others",

    // Page
    "page_manage",
    "page_manage_others",

    // News
    "news_manage",
    "news_manage_others",

    // Review
    "review_manage",
    "review_manage_others",

    //Location
    "location_manage",

    // Settings
    "setting_update",

    // Media
    "media_upload",
    "media_manage_others",

    //Tool
    "tools_view",

    //Language
    "language_manage",
    "language_translation",

    //Role
    "role_manage",

    // User
    "user_manage",

    // Others
    "system_log_view",
    "plugin_manage",
    "menu_manage",
    "report_view",
    "template_manage",
    "contact_manage",
    "newsletter_manage",
    'setting_manage',

    // Custom
    "dashboard_vendor_access"
];
