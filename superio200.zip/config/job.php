<?php
return [
    'job_route_prefix' => env("JOB_ROUTER_PREFIX","job"),
    'job_category_route_prefix' => env("JOB_CATEGORY_ROUTER_PREFIX","category"),
    'job_location_route_prefix' => env("JOB_LOCATION_ROUTER_PREFIX","location"),
];
